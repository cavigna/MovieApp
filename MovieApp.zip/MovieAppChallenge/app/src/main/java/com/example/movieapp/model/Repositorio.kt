package com.example.movieapp.model

import androidx.paging.ExperimentalPagingApi
import androidx.paging.Pager
import androidx.paging.PagingConfig
import androidx.paging.PagingData
import com.example.movieapp.model.local.db.BaseDeDatos
import com.example.movieapp.model.local.db.MovieDao
import com.example.movieapp.model.models.Movie
import com.example.movieapp.model.models.MovieResponse
import com.example.movieapp.model.models.model.MovieDetail
import com.example.movieapp.model.models.paging.MoviePagingSource
import com.example.movieapp.model.models.paging.MovieRemoteMediator2
import com.example.movieapp.model.remote.ApiService
import com.example.movieapp.utils.Resource
import com.example.movieapp.utils.networkBoundResource
import kotlinx.coroutines.Dispatchers.IO
import kotlinx.coroutines.flow.*
import javax.inject.Inject

class Repositorio @Inject constructor(
    private val api: ApiService,
    private val dao: MovieDao,
    private val db: BaseDeDatos
) {
    val selectMovieSearch = dao.selectMovieSearch()
    suspend fun fetchSearchMovie(query: String) = flowOf(api.fetchSearchMovies(query = query))

    suspend fun  selectFavoriteBooks() = flowOf(dao.selectFavorteMovieDetail())



    suspend fun fetchSearchMovieResource(query: String) = flow {
        emit(Resource.success(api.fetchSearchMovies(query = query)))
        //emit(Resource.Success(api.fetchSearchMovies(query = query)))
    }.catch { e ->

        //Resource.error<MovieResponse>(e)
        Resource.error<MovieResponse>(e)

    }

    suspend fun fetchUpComingMovies() = flow {
        emit(Resource.success(api.fetchUpcomingMovies()))
    }.catch { e->

        Resource.error<MovieResponse>(e)
    }

    suspend fun updateMovieDetailFavorite(movie: MovieDetail) = dao.updateMovieDetailsFavorite(movie)

    suspend fun fetchImagesDetail(id:Int) = api.fetchImages(id)




    suspend fun fetchPopularMovies() = flow {
        emit(api.fetchPopularMovies())
    }

    fun selectPopularMovies() = flow {
        emit(dao.selectPopularMovies())
    }

    fun searchMovie(query: String) = networkBoundResource(
        query = { selectMovieSearch },
        fetch = { fetchSearchMovie(query = query) },
        saveFetchResult = {
            dao.insertPopularMovies(api.fetchSearchMovies(query = query).popularMovies)
        }
    )

    fun selectMovieDetailCached(id: Int) = networkBoundResource(
        query = { dao.selectMovieDetailFlow(id) },
        fetch = { api.fetchMovieDetail(id) },
        saveFetchResult = { dao.insertMovieDetail(api.fetchMovieDetail(id)) },
        coroutineDispatcher = IO

    )


    fun fetchOrSelectPopularMovies() = networkBoundResource(
        query = { dao.selectPopularMovies().asFlow() },
        fetch = { api.fetchPopularMovies() },
        saveFetchResult = { dao.insertPopularMovies(api.fetchPopularMovies().popularMovies) },
    )

    /**
     * RECORDAR BUSCAR [CombinedLoadStates]
     *
     * Link [https://developer.android.com/topic/libraries/architecture/paging/load-state?hl=EN]
     */


    @OptIn(ExperimentalPagingApi::class)
    val listadoMoviesPager = Pager(
        config = PagingConfig(1),
        //remoteMediator = MovieRemoteMediator2(api, db),
        // initialKey = 1,
        //pagingSourceFactory = MoviePagingSource(dao, api)
    ) {
        //MovieRemoteMediator2(api, db)
        MoviePagingSource(api, dao)

    }.flow

    @OptIn(ExperimentalPagingApi::class)
    fun listaPagerDB(): Flow<PagingData<Movie>> {
        return Pager(
            config = PagingConfig(1),
            remoteMediator = MovieRemoteMediator2(api, db)
        ) {
            //MovieRemoteMediator(api, db)
            dao.selectMoviesWIthPaging()
        }.flow.catch {

        }
    }

}

/*
    suspend fun fetchSearchMovieResource2(query: String): Flow<Resource<MovieResponse>> = try {
        flow { Resource.success(api.fetchSearchMovies(query = query)) }
    } catch (e: Exception) {
        flow { emit(Resource.error<MovieResponse>(e)) }
    }
 */

/*
    @OptIn(ExperimentalPagingApi::class)
    val listadoMoviesPager = Pager(
        config = PagingConfig(1),
        //remoteMediator = MovieRemoteMediator2(api, db),
        // initialKey = 1,
        //pagingSourceFactory = MoviePagingSource(dao, api)
    ) {
            MoviePagingSource(api, dao)

    }.flow
        .catch {

            emit(PagingData.from(dao.selectPopularMovies()))

        }.flowOn(IO)
 */

/*

    suspend fun fetchPopularMovies() = flow {
        emit(api.fetchPopularMovies())
    }

    suspend fun fetchMovieDetail(id: Int) = flow {
        emit(api.fetchMovieDetail(id))
    }

    suspend fun selectPopularMovie() = flow {
        emit(dao.selectPopularMovies())
    }.flatMapMerge {
        fetchPopularMovies().onEach {
            dao.insertPopularMovies(it.popularMovies)
        }
    }

    suspend fun insertMovieDetail(id: Int) {
        dao.insertMovieDetail(api.fetchMovieDetail(id))
    }

    suspend fun selectAndInsertMovieDetail(id: Int): Flow<MovieDetail> {
        dao.insertMovieDetail(api.fetchMovieDetail(id))

        return flowOf(dao.selectMovieDetail(id))
    }


    fun prueba() = networkBoundResource(
        query = {dao.selectPopularMovies().asFlow()},
        fetch = {api.fetchPopularMovies()},
        saveFetchResult = {dao.insertPopularMovies(api.fetchPopularMovies().popularMovies)}

    )
 */
package com.example.movieapp.ui.states

import com.example.movieapp.model.models.MovieResponse
import com.example.movieapp.model.models.model.MovieDetail

sealed class UiSearchState {
    data class Success(val movieResponse: MovieResponse) : UiSearchState()
    object Loading : UiSearchState()
    object Empty : UiSearchState()
    data class Error(val e:Throwable?,  val message: String) : UiSearchState()


}

sealed class UiUpComingState {
    data class Success(val movieResponse: MovieResponse) : UiUpComingState()
    object Loading : UiUpComingState()
    data class Error(val e:Throwable?,  val message: String) : UiUpComingState()

}

sealed class UiFavoriteState{
    data class Success(val listOfFavorites: List<MovieDetail>):UiFavoriteState()
    data class Error(val e:Throwable?,  val message: String) : UiFavoriteState()
    object  Loading : UiFavoriteState()

    companion object{
        fun success( listOfFavorites: List<MovieDetail>) = listOfFavorites
    }
}
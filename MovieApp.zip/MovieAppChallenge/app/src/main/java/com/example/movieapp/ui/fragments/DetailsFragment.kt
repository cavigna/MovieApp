package com.example.movieapp.ui.fragments

import android.os.Bundle
import android.util.Log
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.CompoundButton
import android.widget.ProgressBar
import android.widget.ScrollView
import android.widget.Toast
import androidx.fragment.app.activityViewModels
import coil.load
import com.example.movieapp.databinding.FragmentDetailsBinding
import com.example.movieapp.ui.states.UiDetailsState
import com.example.movieapp.utils.Resource
import com.example.movieapp.utils.launchAndRepeatWithViewLifecycle
import com.example.movieapp.viewmodel.MainViewModel
import dagger.hilt.android.AndroidEntryPoint
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.collect

@AndroidEntryPoint
class DetailsFragment : Fragment() {
    private val viewModel by activityViewModels<MainViewModel>()
    private lateinit var binding: FragmentDetailsBinding

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {

        binding = FragmentDetailsBinding.inflate(layoutInflater, container, false)

        this.launchAndRepeatWithViewLifecycle {
            viewModel.uiDetailsState.collect {
                when (it) {
                    is UiDetailsState.Loading -> {
                        isLoading(true)
                    }

                    is UiDetailsState.Success -> {
                        isLoading()
                        val movie = it.movieDetail!!
                        with(binding) {
                            imageViewPosterDetails.load("https://image.tmdb.org/t/p/w500${movie.backdropPath}")
                           // Log.v("algo", "https://image.tmdb.org/t/w500/${movie.posterPath}")
                            textViewTiutloDetails.text = movie.title
                            tvOverviewDetails.text = movie.overview
                            tvRelease.text = movie.releaseDate

                            checkBoxBookMark.setOnCheckedChangeListener { _, _ ->
                                viewModel.updateMovieDetail(movie)

                            }
                            when (movie.favorite) {
                                true -> checkBoxBookMark.isChecked = true
                                false -> checkBoxBookMark.isChecked = false
                            }

                        }
                       //Log.v("algo", "https://image.tmdb.org/t/w500/${movie.posterPath}")
                    }

                    is UiDetailsState.Error -> {
                        val error = it.e!!

                        binding.scrollViewDetails.visibility = View.GONE
                        binding.progressBar.visibility = View.GONE
                        Toast.makeText(requireContext(), error.message, Toast.LENGTH_SHORT).show()
                    }
                }
            }
        }

        this.launchAndRepeatWithViewLifecycle {

            //viewModel.imagesDetails.collect {Log.v("algo", it.toString())      }
        }

        return binding.root
    }

    private fun isLoading(
        isLoading: Boolean = false,
        progressBar: ProgressBar = binding.progressBar,
        scrollView: ScrollView = binding.scrollViewDetails
    ) {
        when (isLoading) {
            true -> {
                scrollView.visibility = View.GONE
                progressBar.visibility = View.VISIBLE
            }
            false -> {
                scrollView.visibility = View.VISIBLE
                progressBar.visibility = View.GONE
            }
        }
    }


}

/*
    private fun initWithLiveData() {
        viewModel.selectMovieDetailCached().observe(viewLifecycleOwner, {
            when (it) {
                is Resource.Success -> {
                    val movie = it.data!!
                    with(binding) {
                        imageViewPosterDetails.load("https://image.tmdb.org/t/p/w500${movie.backdropPath}")
                        Log.v("algo", "https://image.tmdb.org/t/w500/${movie.posterPath}")
                        textViewTiutloDetails.text = movie.title
                        tvOverviewDetails.text = movie.overview
                    }
                }
            }
        })
    }

    private fun initWithState() {
        this.launchAndRepeatWithViewLifecycle {
            viewModel.uiDetailsState.collect {
                when (it) {
                    is UiDetailsState.Success -> {
                        val movie = it.movieDetail!!
                        with(binding) {
                            imageViewPosterDetails.load("https://image.tmdb.org/t/p/w500${movie.backdropPath}")
                            Log.v("algo", "https://image.tmdb.org/t/w500/${movie.posterPath}")
                            textViewTiutloDetails.text = movie.title
                            tvOverviewDetails.text = movie.overview
                        }
                    }
                    else -> {
                        UiDetailsState.Loading
                    }
                }

            }
        }
    }
 */
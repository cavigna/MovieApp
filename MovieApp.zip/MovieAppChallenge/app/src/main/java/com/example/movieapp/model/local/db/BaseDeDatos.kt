package com.example.movieapp.model.local.db

import androidx.room.Database
import androidx.room.RoomDatabase
import androidx.room.TypeConverters
import com.example.movieapp.model.models.Movie
import com.example.movieapp.model.models.model.MovieDetail
import com.example.movieapp.utils.Converters

@TypeConverters(Converters::class)
@Database(entities = [Movie::class, MovieDetail::class], version = 1, exportSchema = false)
abstract class BaseDeDatos: RoomDatabase() {
    abstract val dao : MovieDao
}
package com.example.movieapp.ui.states

import androidx.paging.PagingData
import com.example.movieapp.model.models.Movie
import com.example.movieapp.model.models.MovieResponse

sealed class UiHomeState {
    data class Success(val movieResponse: MovieResponse?) : UiHomeState()
    data class Local(val movies: List<Movie>) : UiHomeState()
    object Loading : UiHomeState()
    data class Error(val message: String, val moviesPopuular: List<Movie>)
    data class Prueba(val pagingData: PagingData<Movie>) : UiHomeState()
}




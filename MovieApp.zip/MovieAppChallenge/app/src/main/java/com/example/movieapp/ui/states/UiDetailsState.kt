package com.example.movieapp.ui.states

import com.example.movieapp.model.models.model.MovieDetail
import com.example.movieapp.utils.Resource

sealed class UiDetailsState {
    object Loading: UiDetailsState()
    data class Success( val movieDetail: MovieDetail?): UiDetailsState()
    data class Error(val e: Throwable?): UiDetailsState()
    data class Exito(val movieDetail: Resource.Success<MovieDetail>)
}